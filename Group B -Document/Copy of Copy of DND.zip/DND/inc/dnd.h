typedef struct customer{
    long phno;
    char name[20];
    char status[20];
    char type[20];
    char selection[20];
}customer;

 


void display();
void registration();
void activateDND();
void deactivateDND();
void dial();
void changeDndService();

 